require("dotenv").config();

if (process.env.NODE_ENV === "production" && !process.env.JWT_SECRET) {
    console.error("Set JWT_SECRET in the environment before running in production.");
    process.exit(1);
}
const express = require("express");
const cors = require("cors");
const path = require("path");
const bcrypt = require("bcryptjs");
const { db } = require("./db");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());
// Simple health check (useful for hosting platforms)
app.get("/api/health", (req, res) => res.json({ ok: true, complaints: db.prepare("SELECT COUNT(*) AS n FROM complaints").get().n }));
app.use("/api/auth", require("./routes/auth"));
app.use("/api/complaints", require("./routes/complaints"));
app.use("/api/admin", require("./routes/admin"));
app.use("/api", (req, res) => res.status(404).json({ success: false, message: "API route not found." }));
app.use(express.static(path.join(__dirname, "public")));

// Central error handler
app.use((err, req, res, next) => {
    console.error(err);
    res.status(err.status || 500).json({ success: false, message: err.status ? err.message : "Server error. Please try again." });
});

// Create the first admin on first run, using ADMIN_EMAIL / ADMIN_PASSWORD from .env
const email = (process.env.ADMIN_EMAIL || "admin@ocms.com").toLowerCase();
if (!db.prepare("SELECT id FROM users WHERE email = ?").get(email)) {
    if (process.env.ADMIN_PASSWORD) {
        db.prepare("INSERT INTO users (name, email, password, role, created_at) VALUES (?,?,?,?,?)")
            .run("Administrator", email, bcrypt.hashSync(process.env.ADMIN_PASSWORD, 10), "admin", new Date().toISOString());
        console.log(`Admin created: ${email}`);
    } else {
        console.log('No admin password set. Run: npm run create-admin -- you@example.com "YourPassword" "Your Name"');
    }
}

console.log("Admin accounts:", db.prepare("SELECT email FROM users WHERE role = 'admin'").all().map((r) => r.email).join(", "));

app.listen(PORT, () => console.log(`OCMS running at http://localhost:${PORT}  (SQLite database ready)`));
