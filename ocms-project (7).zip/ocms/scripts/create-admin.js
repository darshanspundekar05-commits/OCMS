// Make any email an admin (or reset its password).
// Usage:  npm run create-admin -- you@example.com YourPassword "Your Name"
require("dotenv").config();
const bcrypt = require("bcryptjs");
const { db } = require("../db");

const [emailArg, password, ...nameParts] = process.argv.slice(2);
if (!emailArg || !password) {
    console.log('Usage: npm run create-admin -- you@example.com YourPassword "Your Name"');
    process.exit(1);
}
if (password.length < 6) {
    console.log("Password must be at least 6 characters.");
    process.exit(1);
}

const email = emailArg.trim().toLowerCase();
const hash = bcrypt.hashSync(password, 10);
const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email);

if (existing) {
    db.prepare("UPDATE users SET password = ?, role = 'admin' WHERE id = ?").run(hash, existing.id);
    console.log(`Done: ${email} is now an admin with the new password.`);
} else {
    db.prepare("INSERT INTO users (name, email, password, role, created_at) VALUES (?,?,?,?,?)")
        .run(nameParts.join(" ") || "Administrator", email, hash, "admin", new Date().toISOString());
    console.log(`Done: admin account created for ${email}.`);
}
console.log("Now open the website, click Admin Login and sign in with this email and password.");
