# CampusCare - College Complaint Management System
Node.js + Express + **SQLite** + vanilla JS. The database is a single file, `ocms.db`, created on first run.

## Run
1. `npm install`
2. Copy `.env.example` to `.env` and set `JWT_SECRET`
3. `npm start`, then open http://localhost:5000 (not the HTML file)

**Admin:** created on first start from `ADMIN_EMAIL` / `ADMIN_PASSWORD` in `.env`.
To change the admin password later (the `.env` value only works the first time):
`npm run create-admin -- admin@ocms.com "NewPassword" "Administrator"`
**Students:** there are no default student accounts. Each student registers with their own email and chooses their own password.
To make **your own email** an admin (or reset a forgotten admin password), run:
`npm run create-admin -- you@example.com YourPassword "Your Name"`

To view the data, open `ocms.db` in the free "DB Browser for SQLite" app.

## Database tables
- **users**(id, name, email, password_hash, role, roll_no, department, created_at)
- **complaints**(id, complaint_id, user_id -> users, category, subject, description, location, phone, priority, status, created_at)
- **status_history**(id, complaint_id -> complaints, status, note, at)

## API
| Method | Route | Access |
|---|---|---|
| POST | /api/auth/register, /api/auth/login | public |
| GET | /api/auth/me | logged in |
| PATCH | /api/auth/password | logged in |
| POST | /api/complaints | logged in |
| GET | /api/complaints/mine | logged in |
| GET | /api/complaints/track/:id | public |
| GET | /api/complaints | admin |
| PATCH | /api/complaints/:id/status | admin |
| DELETE | /api/complaints/:id | admin |
| GET | /api/admin/students | admin |
| GET | /api/admin/stats | admin |

## Deploying
SQLite stores everything in one file, so the host needs a **persistent disk**. Good fits: Render (with a disk), Railway or Fly.io (with a volume), or any VPS.
Static or serverless hosts (Netlify, Vercel) will **not** work: they cannot keep the `ocms.db` file.

Set these environment variables on the host:
- `NODE_ENV=production`
- `JWT_SECRET=` a long random string (required in production)
- `ADMIN_EMAIL` and `ADMIN_PASSWORD` (the first admin, created on first start)
- `DB_FILE=` full path to a file on the persistent disk, e.g. `/data/ocms.db`
- `PORT` is usually set by the host.

Everyone (students and admin) must use the **same** server URL. Each server has its own database, so a complaint made on `localhost` will not appear on a hosted site, and the other way round.
