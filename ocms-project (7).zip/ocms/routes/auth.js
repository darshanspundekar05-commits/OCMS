const router = require("express").Router();
const bcrypt = require("bcryptjs");
const { db } = require("../db");
const { auth, sign } = require("../middleware/auth");

const pub = (u) => ({ id: u.id, name: u.name, email: u.email, role: u.role, rollNo: u.roll_no, department: u.department });
const bad = (res, code, message) => res.status(code).json({ success: false, message });

router.post("/register", (req, res) => {
    const { name, password, rollNo, department } = req.body;
    const email = String(req.body.email || "").trim().toLowerCase();
    if (!name || !name.trim()) return bad(res, 400, "Name is required.");
    if (!/^\S+@\S+\.\S+$/.test(email)) return bad(res, 400, "Enter a valid email.");
    if (String(password || "").length < 6) return bad(res, 400, "Password must be at least 6 characters.");
    if (!rollNo || !department) return bad(res, 400, "Roll number and department are required.");
    if (db.prepare("SELECT id FROM users WHERE email = ?").get(email))
        return bad(res, 409, "This email is already registered. Log in instead.");

    const info = db.prepare("INSERT INTO users (name, email, password, roll_no, department, created_at) VALUES (?,?,?,?,?,?)")
        .run(name.trim(), email, bcrypt.hashSync(password, 10), String(rollNo).trim(), department, new Date().toISOString());
    const user = db.prepare("SELECT * FROM users WHERE id = ?").get(info.lastInsertRowid);
    res.status(201).json({ success: true, token: sign(user), user: pub(user) });
});

router.post("/login", (req, res) => {
    const want = req.body.role;
    if (!["user", "admin"].includes(want)) return bad(res, 400, "Please choose Student or Admin login.");
    const user = db.prepare("SELECT * FROM users WHERE email = ?").get(String(req.body.email || "").trim().toLowerCase());
    if (!user || !bcrypt.compareSync(String(req.body.password || ""), user.password))
        return bad(res, 401, "Incorrect email or password.");
    if (want === "admin" && user.role !== "admin") return bad(res, 403, "This is not an admin account. Please use the student login.");
    if (want === "user" && user.role === "admin") return bad(res, 403, "This is an admin account. Please use Admin Login.");
    res.json({ success: true, token: sign(user), user: pub(user) });
});

// Logged-in user changes their own password
router.patch("/password", auth, (req, res) => {
    const { currentPassword, newPassword } = req.body;
    if (!bcrypt.compareSync(String(currentPassword || ""), req.user.password)) return bad(res, 400, "Current password is incorrect.");
    if (String(newPassword || "").length < 6) return bad(res, 400, "New password must be at least 6 characters.");
    if (newPassword === currentPassword) return bad(res, 400, "New password must be different from the current one.");
    db.prepare("UPDATE users SET password = ? WHERE id = ?").run(bcrypt.hashSync(newPassword, 10), req.user.id);
    res.json({ success: true, message: "Password changed." });
});

router.get("/me", auth, (req, res) => res.json({ success: true, user: pub(req.user) }));

module.exports = router;
