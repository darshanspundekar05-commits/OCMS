const router = require("express").Router();
const { db, CATEGORIES, STATUSES } = require("../db");
const { auth, admin } = require("../middleware/auth");

router.use(auth, admin);

// All registered students with how many complaints each has
router.get("/students", (req, res) => {
    const rows = db.prepare(`SELECT u.id, u.name, u.email, u.roll_no, u.department, u.created_at,
            (SELECT COUNT(*) FROM complaints WHERE user_id = u.id) AS total,
            (SELECT COUNT(*) FROM complaints WHERE user_id = u.id AND status NOT IN ('Resolved','Rejected')) AS open
        FROM users u WHERE u.role = 'user' ORDER BY u.id DESC`).all();
    res.json({ success: true, students: rows.map((r) => ({
        id: r.id, name: r.name, email: r.email, rollNo: r.roll_no, department: r.department,
        joined: r.created_at, total: r.total, open: r.open
    })) });
});

// Complaint statistics for the dashboard
router.get("/stats", (req, res) => {
    const count = (col, keys) => {
        const out = Object.fromEntries(keys.map((k) => [k, 0]));
        db.prepare(`SELECT ${col} AS k, COUNT(*) AS n FROM complaints GROUP BY ${col}`).all().forEach((r) => { out[r.k] = r.n; });
        return out;
    };
    const total = db.prepare("SELECT COUNT(*) AS n FROM complaints").get().n;
    const byStatus = count("status", STATUSES);
    const byDepartment = {};
    db.prepare("SELECT u.department AS k, COUNT(*) AS n FROM complaints c JOIN users u ON u.id = c.user_id GROUP BY u.department ORDER BY n DESC")
        .all().forEach((r) => { byDepartment[r.k || "Unknown"] = r.n; });
    res.json({ success: true, stats: {
        total, byStatus, byCategory: count("category", CATEGORIES), byPriority: count("priority", ["Low", "Medium", "High"]),
        byDepartment, resolved: total ? Math.round((byStatus.Resolved * 100) / total) : 0
    } });
});

module.exports = router;
