"use strict";

const $ = (s) => document.querySelector(s);
const CATS = [
    ["⚡", "Electricity", "Lights, fans, sockets and power problems."],
    ["💧", "Water Supply", "Drinking water, leakage and tap problems."],
    ["💻", "Computer/Lab", "Computers, lab equipment and software issues."],
    ["🧹", "Cleaning & Sanitation", "Washrooms, garbage and cleanliness."],
    ["🪑", "Furniture", "Broken benches, desks, chairs and cupboards."],
    ["🌐", "Internet/Network", "Wi-Fi, LAN and connectivity problems."],
    ["🏫", "Classroom/Infrastructure", "Classrooms, projectors, boards and buildings."],
    ["🔧", "General Maintenance", "Repairs and other maintenance work."]
];
const STATUSES = ["Submitted", "Under Review", "In Progress", "Resolved", "Rejected"];
const PROGRESS = { Submitted: 15, "Under Review": 40, "In Progress": 75, Resolved: 100, Rejected: 100 };

let token = sessionStorage.getItem("token");
let user = JSON.parse(sessionStorage.getItem("user") || "null");
let list = [];

// Escape user text before putting it in HTML (prevents XSS)
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmt = (d) => new Date(d).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
const badge = (s) => `<span class="badge ${esc(s)}">${esc(s)}</span>`;

async function api(path, { method = "GET", body } = {}) {
    const res = await fetch("/api" + path, {
        method,
        headers: { "Content-Type": "application/json", ...(token && { Authorization: "Bearer " + token }) },
        body: body && JSON.stringify(body)
    }).catch(() => {
        throw new Error(location.protocol === "file:"
            ? "Do not open the HTML file directly. Run npm start, then open http://localhost:5000"
            : "Cannot reach the server. Check that npm start is running.");
    });
    const data = await res.json().catch(() => ({}));
    if (res.status === 401 && token) logout(true);
    if (!res.ok) throw new Error(data.message || "Something went wrong.");
    return data;
}

function toast(msg, bad) {
    const t = $("#toast");
    t.textContent = msg;
    t.className = "show" + (bad ? " bad" : "");
    clearTimeout(toast.t);
    toast.t = setTimeout(() => (t.className = ""), 3200);
}

/* ---------- Auth ---------- */
let mode = "login", role = "user";
function setMode(m) {
    mode = m;
    const reg = m === "register";
    if (reg) role = "user"; // only students can register
    $("#authTitle").textContent = reg ? "Create student account" : role === "admin" ? "Admin login" : "Student login";
    $("#authBtn").textContent = reg ? "Create account" : "Log in";
    $("#nameRow").hidden = !reg;
    $("#nameRow input").required = reg;
    $("#regRow").hidden = !reg;
    $("#regRow input").required = reg;
    $("#regRow select").required = reg;
    $("#authSwitchText").textContent = reg ? "Already registered?" : "New here?";
    $("#authSwitch").textContent = reg ? "Log in" : "Create an account";
    $("#authErr").textContent = "";
    $("#authForm [name=password]").type = "password";
    $("#pwToggle").textContent = "Show";
    $(".switch").hidden = role === "admin";
}
function openAuth(m, r = "user") { role = r; setMode(m); $("#authDlg").showModal(); }

function renderNav() {
    document.body.dataset.role = user ? user.role : "guest";
    $("#navAuth").innerHTML = user
        ? `<span class="role-badge">${user.role === "admin" ? "Admin" : "Student"}</span><span class="hi">${esc(user.name.split(" ")[0])}</span><button class="btn btn-light" data-act="password">Change password</button><button class="btn btn-light" data-act="logout">Log out</button>`
        : `<button class="btn btn-light" data-act="adminlogin">Admin Login</button><button class="btn btn-blue" data-act="register">Student Register</button>`;
    $("#navDash").hidden = !user;
}

function logout(silent) {
    token = null; user = null;
    sessionStorage.removeItem("token"); sessionStorage.removeItem("user");
    renderNav(); loadDash();
    window.scrollTo(0, 0);
    if (!silent) toast("Logged out.");
}

$("#authSwitch").onclick = (e) => { e.preventDefault(); setMode(mode === "login" ? "register" : "login"); };

$("#authForm").onsubmit = async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    if (mode === "login") f.role = role;
    try {
        const d = await api("/auth/" + mode, { method: "POST", body: f });
        token = d.token; user = d.user;
        sessionStorage.setItem("token", token); sessionStorage.setItem("user", JSON.stringify(user));
        $("#authDlg").close(); e.target.reset();
        renderNav(); loadDash().then(() => { if (user && user.role === "admin") $("#dashboard").scrollIntoView({ behavior: "smooth" }); });
        toast(mode === "register" ? "Account created." : "Welcome back, " + user.name.split(" ")[0] + ".");
        if (pendingSubmit) { pendingSubmit = false; openSubmit(); }
    } catch (err) {
        // Email already has an account: switch to the login form, keeping what was typed
        if (mode === "register" && /already registered/i.test(err.message)) {
            setMode("login");
            $("#authErr").textContent = "This email is already registered. Log in with it below.";
            return;
        }
        $("#authErr").textContent = err.message;
    }
};

/* ---------- Submit complaint ---------- */
let pendingSubmit = false;
function openSubmit(cat) {
    if (!user) { pendingSubmit = true; toast("Log in or register to submit a complaint."); return openAuth("login"); }
    if (cat) $("#catSel").value = cat;
    $("#subErr").textContent = "";
    $("#subDlg").showModal();
}

$("#subForm").onsubmit = async (e) => {
    e.preventDefault();
    try {
        const d = await api("/complaints", { method: "POST", body: Object.fromEntries(new FormData(e.target)) });
        $("#subDlg").close(); e.target.reset();
        $("#trackId").value = d.complaint.complaintId;
        track(d.complaint.complaintId);
        loadDash();
        showDone(d.complaint.complaintId);
    } catch (err) { $("#subErr").textContent = err.message; }
};

/* ---------- Track ---------- */
async function track(id) {
    const box = $("#trackResult");
    try {
        const { complaint: c } = await api("/complaints/track/" + encodeURIComponent(id));
        box.innerHTML = `
          <div class="res-top"><div><small>${esc(c.category)}</small><h3>${esc(c.complaintId)}</h3></div>${badge(c.status)}</div>
          <div class="row"><span>Complaint</span><strong>${esc(c.subject)}</strong></div>
          <div class="row"><span>Submitted</span><strong>${fmt(c.createdAt)}</strong></div>
          <div class="bar"><i style="width:${PROGRESS[c.status]}%"></i></div>
          <small class="muted">${PROGRESS[c.status]}% complete</small>
          <ul class="timeline">${[...c.history].reverse().map((h) => `<li><b>${esc(h.status)}</b> ${esc(h.note)}<small>${fmt(h.at)}</small></li>`).join("")}</ul>`;
    } catch (err) { box.innerHTML = `<p class="error">${esc(err.message)}</p>`; }
}
$("#trackForm").onsubmit = (e) => { e.preventDefault(); track($("#trackId").value); };

/* ---------- Dashboard (user = own complaints, admin = all) ---------- */
async function loadDash() {
    const sec = $("#dashboard");
    if (!user) { sec.hidden = true; return; }
    const admin = user.role === "admin";
    try {
        list = (await api(admin ? "/complaints" : "/complaints/mine")).complaints;
    } catch (e) { return toast(e.message, true); }
    sec.hidden = false;
    $("#dashTitle").textContent = admin ? "Admin panel: all complaints" : "My complaints";
    $("#dashSub").textContent = admin ? "Click any complaint to see the student's details and update its status." : `Welcome, ${user.name}${user.rollNo ? " · " + user.rollNo : ""}${user.department ? " · " + user.department : ""}. Click a row to see its live status.`;
    $("#search").placeholder = admin ? "Search subject, ID or student" : "Search subject or ID";
    $("#filter").innerHTML = `<option value="">All statuses</option>` + STATUSES.map((s) => `<option>${s}</option>`).join("");
    renderDash();
    if (!admin) tab = "complaints";
    setTab(tab);
}

function renderDash() {
    const admin = user.role === "admin";
    $("#stuTh").hidden = !admin;
    $("#priTh").hidden = !admin;
    const q = $("#search").value.toLowerCase(), f = $("#filter").value;
    const count = (s) => list.filter((c) => c.status === s).length;
    const urgent = list.filter((c) => c.priority === "High" && !["Resolved", "Rejected"].includes(c.status)).length;
    const cards = admin
        ? [["Total", list.length], ["New", count("Submitted")], ["Under Review", count("Under Review")], ["In Progress", count("In Progress")], ["Resolved", count("Resolved")], ["High priority open", urgent]]
        : [["Total", list.length], ["Submitted", count("Submitted")], ["In Progress", count("In Progress")], ["Resolved", count("Resolved")]];
    $("#chips").innerHTML = cards.map(([l, n]) => `<div class="chip"><strong>${n}</strong><span>${l}</span></div>`).join("");
    const shown = list.filter((c) => (!f || c.status === f) && (c.subject + c.complaintId + (c.studentName || "") + (c.rollNo || "")).toLowerCase().includes(q));
    $("#rows").innerHTML = shown.length
        ? shown.map((c) => `<tr class="click" data-id="${esc(c.complaintId)}"><td><b>${esc(c.complaintId)}</b></td><td class="wrap">${esc(c.subject)}</td>${admin ? `<td>${esc(c.studentName || "-")}<br><small class="muted">${esc(c.rollNo || "")} ${esc(c.department || "")}</small></td>` : ""}<td>${esc(c.category)}</td>${admin ? `<td>${badge(c.priority)}</td>` : ""}<td>${fmt(c.createdAt)}</td><td>${badge(c.status)}</td></tr>`).join("")
        : `<tr><td colspan="7"><span class="empty">${list.length ? "No complaints match your filter." : admin ? "No complaints yet." : "You have not submitted a complaint yet. Use the button above or pick a category below."}</span></td></tr>`;
}
$("#search").oninput = () => renderDash();
$("#filter").onchange = () => renderDash();

$("#rows").onclick = (e) => {
    const tr = e.target.closest("tr[data-id]");
    if (!tr) return;
    if (user.role === "admin") return openDetail(tr.dataset.id);
    $("#trackId").value = tr.dataset.id; track(tr.dataset.id);
    $("#tracker").scrollIntoView({ behavior: "smooth" });
};

// Admin: full complaint view with a status update form
async function openDetail(id) {
    const c = list.find((x) => x.complaintId === id);
    let history = [];
    try { history = (await api("/complaints/track/" + encodeURIComponent(id))).complaint.history; } catch (e) { /* timeline is optional */ }
    $("#detailBody").innerHTML = `
      <div class="res-top"><div><small>${esc(c.category)}</small><h2>${esc(c.complaintId)}</h2></div>${badge(c.status)}</div>
      <p class="desc">${esc(c.description)}</p>
      <div class="row"><span>Student</span><strong>${esc(c.studentName)} (${esc(c.rollNo || "-")})</strong></div>
      <div class="row"><span>Department</span><strong>${esc(c.department || "-")}</strong></div>
      <div class="row"><span>Contact</span><strong>${esc(c.studentEmail)}${c.phone ? " · " + esc(c.phone) : ""}</strong></div>
      <div class="row"><span>Priority</span>${badge(c.priority)}</div>
      <ul class="timeline">${[...history].reverse().map((h) => `<li><b>${esc(h.status)}</b> ${esc(h.note)}<small>${fmt(h.at)}</small></li>`).join("")}</ul>
      <form id="statusForm" data-id="${esc(id)}">
        <label>Update status<select name="status">${STATUSES.map((s) => `<option ${s === c.status ? "selected" : ""}>${s}</option>`).join("")}</select></label>
        <label>Note for the student<input name="note" maxlength="200" placeholder="e.g. Electrician assigned, will be fixed tomorrow"></label>
        <div class="quick"><button type="button" class="btn btn-ok" data-quick="Resolved">&#10003; Resolve</button><button type="button" class="btn btn-no" data-quick="Rejected">&#10005; Reject</button><button class="btn btn-blue">Save update</button></div>
        <button type="button" class="linkdanger" data-del="${esc(id)}">Delete this complaint</button>
      </form>`;
    $("#detailDlg").showModal();
}

$("#detailBody").onsubmit = async (e) => {
    e.preventDefault();
    const id = e.target.dataset.id, body = Object.fromEntries(new FormData(e.target));
    try {
        await api(`/complaints/${id}/status`, { method: "PATCH", body });
        $("#detailDlg").close();
        toast(`${id} updated to ${body.status}.`);
        loadDash();
    } catch (err) { toast(err.message, true); }
};


/* ---------- Student: confirmation ---------- */
let lastId = "";
function showDone(id) { lastId = id; $("#doneId").textContent = id; $("#doneDlg").showModal(); }
$("#copyId").onclick = async () => {
    try { await navigator.clipboard.writeText(lastId); toast("Complaint ID copied."); }
    catch { toast("Select the ID and copy it manually.", true); }
};
$("#trackNow").onclick = () => {
    $("#doneDlg").close();
    $("#trackId").value = lastId; track(lastId);
    $("#tracker").scrollIntoView({ behavior: "smooth" });
};

/* ---------- Admin: tabs, students, statistics, quick actions ---------- */
let tab = "complaints";
function setTab(t) {
    tab = t;
    document.querySelectorAll("#adminTabs button").forEach((b) => b.classList.toggle("on", b.dataset.tab === t));
    ["complaints", "students", "stats"].forEach((n) => ($("#tab-" + n).hidden = n !== t));
    $(".dash-tools").hidden = t !== "complaints";
    if (t === "students") loadStudents();
    if (t === "stats") loadStats();
}

async function loadStudents() {
    try {
        const { students } = await api("/admin/students");
        $("#stuRows").innerHTML = students.length
            ? students.map((s) => `<tr><td><b>${esc(s.name)}</b></td><td>${esc(s.rollNo || "-")}</td><td>${esc(s.department || "-")}</td><td>${esc(s.email)}</td><td>${s.total}</td><td>${s.open}</td><td>${fmt(s.joined)}</td></tr>`).join("")
            : `<tr><td colspan="7"><span class="empty">No students have registered yet.</span></td></tr>`;
    } catch (e) { toast(e.message, true); }
}

async function loadStats() {
    try {
        const { stats: s } = await api("/admin/stats");
        const panel = (title, obj) => {
            const max = Math.max(1, ...Object.values(obj));
            const rows = Object.entries(obj).map(([k, v]) => `<div class="bar-row"><span>${esc(k)}</span><div class="meter"><i style="width:${(v / max) * 100}%"></i></div><b>${v}</b></div>`).join("");
            return `<div class="panel"><h3>${title}</h3>${rows || '<p class="muted">No data yet.</p>'}</div>`;
        };
        $("#statsBody").innerHTML = `<div class="panel big"><strong>${s.total}</strong><span>Total complaints</span><small class="muted">${s.resolved}% resolved</small></div>`
            + panel("By status", s.byStatus) + panel("By complaint type", s.byCategory) + panel("By priority", s.byPriority) + panel("By department", s.byDepartment);
    } catch (e) { toast(e.message, true); }
}

$("#detailBody").onclick = (e) => {
    const q = e.target.closest("[data-quick]");
    if (q) { const f = $("#statusForm"); f.status.value = q.dataset.quick; f.requestSubmit(); }
    const d = e.target.closest("[data-del]");
    if (d) {
        if (!d.dataset.sure) { d.dataset.sure = "1"; d.textContent = "Click again to confirm delete"; return; }
        api("/complaints/" + d.dataset.del, { method: "DELETE" })
            .then(() => { $("#detailDlg").close(); toast(d.dataset.del + " deleted."); loadDash(); })
            .catch((err) => toast(err.message, true));
    }
};

/* ---------- Change own password ---------- */
$("#pwShowAll").onchange = (e) => document.querySelectorAll(".pwf").forEach((i) => (i.type = e.target.checked ? "text" : "password"));
$("#pwForm").onsubmit = async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    if (f.newPassword !== f.confirm) { $("#pwErr").textContent = "The new passwords do not match."; return; }
    try {
        await api("/auth/password", { method: "PATCH", body: { currentPassword: f.currentPassword, newPassword: f.newPassword } });
        $("#pwDlg").close();
        toast("Password changed. Use the new one next time you log in.");
    } catch (err) { $("#pwErr").textContent = err.message; }
};

/* ---------- Complaint form: friendly length message ---------- */
const descBox = $("#subForm [name=description]");
descBox.oninput = () => descBox.setCustomValidity(descBox.value.trim().length < 10 ? "Please describe the problem in at least 10 characters." : "");

/* ---------- Keep the list up to date (new complaints / status changes) ---------- */
async function refreshList() {
    if (!user) return;
    try {
        list = (await api(user.role === "admin" ? "/complaints" : "/complaints/mine")).complaints;
        renderDash();
        if (tab === "students") loadStudents();
        if (tab === "stats") loadStats();
    } catch (e) { /* try again next time */ }
}
$("#refreshBtn").onclick = async () => { await refreshList(); toast("List updated."); };
setInterval(() => { if (user && !document.hidden && !$("#detailDlg").open && !$("#subDlg").open) refreshList(); }, 15000);

/* ---------- Wiring ---------- */
document.addEventListener("click", (e) => {
    const a = e.target.closest("[data-act]");
    if (a) {
        const act = a.dataset.act;
        if (act === "login" || act === "register") openAuth(act);
        if (act === "adminlogin") openAuth("login", "admin");
        if (act === "logout") logout();
        if (act === "submit") openSubmit();
        if (act === "password") {
            $("#pwForm").reset(); $("#pwErr").textContent = "";
            document.querySelectorAll(".pwf").forEach((i) => (i.type = "password"));
            $("#pwDlg").showModal();
        }
    }
    if (e.target.closest("[data-close]")) e.target.closest("dialog").close();
    if (e.target.id === "pwToggle") {
        const box = $("#authForm [name=password]"), show = box.type === "password";
        box.type = show ? "text" : "password";
        e.target.textContent = show ? "Hide" : "Show";
        e.target.setAttribute("aria-label", show ? "Hide password" : "Show password");
    }
    const tb = e.target.closest("[data-tab]");
    if (tb) setTab(tb.dataset.tab);
    const card = e.target.closest("[data-cat]");
    if (card) openSubmit(card.dataset.cat);
});

document.addEventListener("DOMContentLoaded", async () => {
    $("#cards").innerHTML = CATS.map(([i, n, d]) => `<button class="card" data-cat="${esc(n)}"><div class="icon">${i}</div><h3>${esc(n)}</h3><p>${esc(d)}</p></button>`).join("");
    $("#catSel").innerHTML = CATS.map((c) => `<option>${esc(c[1])}</option>`).join("");
    $("#heroStats").innerHTML = [["24/7", "Access"], ["Instant", "Complaint ID"], ["Live", "Status updates"]].map(([a, b]) => `<div><strong>${a}</strong><span>${b}</span></div>`).join("");
    renderNav();
    if (token) { try { user = (await api("/auth/me")).user; } catch { /* logout handled in api() */ } }
    renderNav(); loadDash();
});
